#!/bin/bash
echo 'SerixOS bootstrap'